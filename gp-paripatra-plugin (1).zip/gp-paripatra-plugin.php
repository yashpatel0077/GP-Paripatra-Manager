<?php
/*
Plugin Name: GP Paripatra Manager
Description: Paripatra with PDF Upload + Filters + Pagination + Read Button + Table Design.
Version: 4.1
Author: Yash Patel
*/

if (!defined('ABSPATH')) exit;

/* ----------------------------------------------------------
   ADMIN COLUMN: PARIPATRA DATE (gp_date)
---------------------------------------------------------- */
add_filter('manage_paripatra_posts_columns', function ($columns) {
    $new = [];
    foreach ($columns as $key => $label) {
        $new[$key] = $label;
        if ($key === 'title') {
            $new['gp_date'] = 'પરિપત્ર તારીખ';
        }
    }
    return $new;
});

add_action('manage_paripatra_posts_custom_column', function ($column, $post_id) {
    if ($column === 'gp_date') {
        $date = get_post_meta($post_id, 'gp_date', true);
        if ($date) echo esc_html(date('d-m-Y', strtotime($date)));
        else echo '—';
    }
}, 10, 2);

/* ----------------------------------------------------------
   NORMALIZE TEXT
---------------------------------------------------------- */
function gp_normalize_text($str)
{
    $str = wp_unslash($str);
    $str = str_replace(["“", "”", "„", "‟", "’", "‘"], ['"', '"', '"', '"', "'", "'"], $str);
    $str = trim(preg_replace('/\s+/u', ' ', $str));
    return $str;
}

/**
 * Dedupe key = same Type + Date + Title + Subject
 */
function gp_dedupe_key_same_fields($type, $dateRaw, $title, $subject)
{
    $type    = gp_normalize_text((string)$type);
    $dateRaw = gp_normalize_text((string)$dateRaw);
    $title   = gp_normalize_text((string)$title);
    $subject = gp_normalize_text((string)$subject);

    $key = $type . '|' . $dateRaw . '|' . $title . '|' . $subject;
    return function_exists('mb_strtolower') ? mb_strtolower($key, 'UTF-8') : strtolower($key);
}

/* ----------------------------------------------------------
   REGISTER CPT
---------------------------------------------------------- */
function gp_register_paripatra_cpt()
{
    register_post_type('paripatra', [
        'label' => 'Paripatra',
        'public' => true,
        'show_in_menu' => true,
        'supports' => ['title'],
    ]);
}
add_action('init', 'gp_register_paripatra_cpt');

/* ----------------------------------------------------------
   METABOX
---------------------------------------------------------- */
function gp_add_metaboxes()
{
    add_meta_box('gp_details', 'Paripatra Details', 'gp_details_box', 'paripatra', 'normal');
}
add_action('add_meta_boxes', 'gp_add_metaboxes');

function gp_details_box($post)
{
    wp_enqueue_media();

    $date = get_post_meta($post->ID, 'gp_date', true);
    $title = get_post_meta($post->ID, 'gp_title', true);
    $subject = get_post_meta($post->ID, 'gp_subject', true);
    $type = get_post_meta($post->ID, 'gp_type', true);
    $pdf = get_post_meta($post->ID, 'gp_pdf', true);

    if ($date && preg_match('#^(\d{4})-(\d{2})-(\d{2})$#', $date, $m)) {
        $date = $m[3] . '/' . $m[2] . '/' . $m[1];
    }

    wp_nonce_field('gp_save_meta_nonce', 'gp_meta_nonce');
    ?>
    <style>
        .gp-metabox-row { margin-bottom: 12px; }
        .gp-metabox-row label { display: block; margin-bottom: 6px; font-weight: 600; }
        .gp-metabox-row input[type="text"],
        .gp-metabox-row input[type="date"] { width: 100%; padding: 6px; box-sizing: border-box; }
    </style>

    <div class="gp-metabox-row">
        <label>પરિપત્રનો પ્રકાર:</label>
        <input type="text" name="gp_type" id="gp_type" value="<?php echo esc_attr($type); ?>" class="widefat" />
    </div>

    <div class="gp-metabox-row">
        <label>તારીખ (dd/mm/yyyy):</label>
        <input type="text" id="gp_date" name="gp_date" value="<?php echo esc_attr($date); ?>" placeholder="dd/mm/yyyy" />
        <small>Type or paste date in dd/mm/yyyy format</small>
    </div>

    <div class="gp-metabox-row">
        <label>શીર્ષક:</label>
        <input type="text" name="gp_title" value="<?php echo esc_attr($title); ?>" />
    </div>

    <div class="gp-metabox-row">
        <label>વિષય:</label>
        <input type="text" name="gp_subject" value="<?php echo esc_attr($subject); ?>" />
    </div>

    <div class="gp-metabox-row">
        <label>Upload PDF:</label>
        <input type="hidden" name="gp_pdf" id="gp_pdf" value="<?php echo esc_attr($pdf); ?>">
        <button type="button" class="button" id="gp_pdf_btn">Choose PDF</button>
        <span id="gp_pdf_name" style="margin-left:10px;">
            <?php echo $pdf ? basename($pdf) : ''; ?>
        </span>
    </div>

    <script>
        jQuery(document).ready(function ($) {
            $("#gp_pdf_btn").on("click", function (e) {
                e.preventDefault();
                var frame = wp.media({
                    title: "Select PDF",
                    library: { type: "application/pdf" },
                    multiple: false
                });
                frame.on("select", function () {
                    var obj = frame.state().get("selection").first().toJSON();
                    $("#gp_pdf").val(obj.url);
                    $("#gp_pdf_name").text(obj.filename || obj.url.split('/').pop());
                });
                frame.open();
            });

            $("#gp_date").on("input", function () {
                let v = $(this).val();
                v = v.replace(/[^0-9\/\-\.]/g, "");
                v = v.replace(/[-\.]/g, "/");
                v = v.replace(/\/+/g, "/");
                v = v.replace(/^(\d{2})(\d)/, "$1/$2");
                v = v.replace(/^(\d{2}\/\d{2})(\d)/, "$1/$2");
                if (v.length > 10) v = v.substring(0, 10);
                $(this).val(v);
            });

            $("#gp_date").on("paste", function (e) {
                e.preventDefault();
                var clipboard = (e.originalEvent || e).clipboardData.getData('text/plain');
                clipboard = clipboard.trim();
                var digits = clipboard.replace(/[^\d]/g, "");
                let out = "";
                if (digits.length === 8) {
                    let p1 = parseInt(digits.substr(0, 2), 10);
                    if (p1 > 31) out = digits.substr(6, 2) + "/" + digits.substr(4, 2) + "/" + digits.substr(0, 4);
                    else out = digits.substr(0, 2) + "/" + digits.substr(2, 2) + "/" + digits.substr(4, 4);
                } else if (digits.length === 6) {
                    out = digits.substr(0, 2) + "/" + digits.substr(2, 2) + "/20" + digits.substr(4, 2);
                } else {
                    let parts = clipboard.split(/[^0-9]+/).filter(Boolean);
                    if (parts.length >= 3) {
                        if (parts[0].length === 4) out = parts[2].padStart(2, "0") + "/" + parts[1].padStart(2, "0") + "/" + parts[0];
                        else out = parts[0].padStart(2, "0") + "/" + parts[1].padStart(2, "0") + "/" + parts[2].padStart(4, "0");
                    }
                }
                if (out) $(this).val(out);
            });
        });
    </script>
    <?php
}

/* ----------------------------------------------------------
   SAVE META
---------------------------------------------------------- */
function gp_save_meta($post_id)
{
    if (isset($_POST['gp_meta_nonce'])) {
        if (!wp_verify_nonce($_POST['gp_meta_nonce'], 'gp_save_meta_nonce')) return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    if (isset($_POST['gp_date'])) {
        $raw = trim(sanitize_text_field($_POST['gp_date']));
        $saved_date = '';

        if (preg_match('#^(\d{4})-(\d{1,2})-(\d{1,2})$#', $raw, $m)) {
            $saved_date = str_pad($m[1], 4, '0', STR_PAD_LEFT) . '-' . str_pad($m[2], 2, '0', STR_PAD_LEFT) . '-' . str_pad($m[3], 2, '0', STR_PAD_LEFT);
        } elseif (preg_match('#^(\d{1,2})[\/\-\.\s](\d{1,2})[\/\-\.\s](\d{2,4})$#', $raw, $m)) {
            $d = str_pad($m[1], 2, '0', STR_PAD_LEFT);
            $mo = str_pad($m[2], 2, '0', STR_PAD_LEFT);
            $y = $m[3];
            if (strlen($y) === 2) $y = '20' . $y;
            $y = str_pad($y, 4, '0', STR_PAD_LEFT);
            if (checkdate((int)$mo, (int)$d, (int)$y)) {
                $saved_date = $y . '-' . $mo . '-' . $d;
            }
        } elseif (preg_match('#^(\d{2})(\d{2})(\d{4})$#', $raw, $m)) {
            $saved_date = $m[3] . '-' . $m[2] . '-' . $m[1];
        }

        update_post_meta($post_id, 'gp_date', $saved_date);
    }

    foreach (['gp_title', 'gp_subject', 'gp_type'] as $f) {
        if (isset($_POST[$f])) {
            $val = gp_normalize_text(sanitize_text_field($_POST[$f]));
            update_post_meta($post_id, $f, $val);
        }
    }

    if (isset($_POST['gp_pdf'])) {
        update_post_meta($post_id, 'gp_pdf', esc_url_raw($_POST['gp_pdf']));
    }
}
add_action('save_post', 'gp_save_meta');

/* ----------------------------------------------------------
   SHORTCODE TABLE
---------------------------------------------------------- */
function gp_table_shortcode()
{
    $filter_date_input = $_GET['gp_date'] ?? '';
    $filter_title      = $_GET['gp_title'] ?? '';
    $filter_subject    = $_GET['gp_subject'] ?? '';
    $filter_type_raw   = $_GET['gp_type'] ?? '';
    $filter_type       = gp_normalize_text($filter_type_raw);

    /* Date filter conversion */
    $filter_date = '';
    $fd = trim($filter_date_input);
    if ($fd) {
        if (preg_match('#^(\d{1,2})[\/\-\.\s](\d{1,2})[\/\-\.\s](\d{2,4})$#', $fd, $m)) {
            $d = str_pad($m[1], 2, '0', STR_PAD_LEFT);
            $mo = str_pad($m[2], 2, '0', STR_PAD_LEFT);
            $y = $m[3];
            if (strlen($y) === 2) $y = '20' . $y;
            $filter_date = $y . '-' . $mo . '-' . $d;
        } elseif (preg_match('#^(\d{4})-(\d{1,2})-(\d{1,2})$#', $fd, $m)) {
            $filter_date = $m[1] . '-' . str_pad($m[2], 2, '0') . '-' . str_pad($m[3], 2, '0');
        }
    }

    $paged    = max(1, (int)($_GET['pg'] ?? 1));
    $per_page = 10;

    $meta_query = ['relation' => 'AND'];
    if ($filter_date)    $meta_query[] = ['key' => 'gp_date', 'value' => $filter_date];
    if ($filter_title)   $meta_query[] = ['key' => 'gp_title', 'value' => $filter_title, 'compare' => 'LIKE'];
    if ($filter_subject) $meta_query[] = ['key' => 'gp_subject', 'value' => $filter_subject, 'compare' => 'LIKE'];
    if ($filter_type)    $meta_query[] = ['key' => 'gp_type', 'value' => $filter_type, 'compare' => '='];

    /* 🔥 FIX: only published posts (deleted won't show) */
    $query = new WP_Query([
        'post_type'      => 'paripatra',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'meta_query'     => $meta_query,
        'meta_key'       => 'gp_date',
        'orderby'        => ['meta_value' => 'DESC', 'ID' => 'DESC'],
    ]);

    /* Remove duplicates */
    $unique_rows = [];
    $seen = [];

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();

            $type    = get_post_meta(get_the_ID(), 'gp_type', true);
            $dateRaw = get_post_meta(get_the_ID(), 'gp_date', true);
            $title   = get_post_meta(get_the_ID(), 'gp_title', true);
            $subject = get_post_meta(get_the_ID(), 'gp_subject', true);
            $pdf     = get_post_meta(get_the_ID(), 'gp_pdf', true);

            $key = gp_dedupe_key_same_fields($type, $dateRaw, $title, $subject);
            if (isset($seen[$key])) continue;
            $seen[$key] = true;

            $unique_rows[] = [
                'type'    => $type,
                'dateRaw' => $dateRaw,
                'title'   => $title,
                'subject' => $subject,
                'pdf'     => $pdf
            ];
        }
    }
    wp_reset_postdata();

    $total_unique = count($unique_rows);
    $total_pages  = max(1, (int)ceil($total_unique / $per_page));
    if ($paged > $total_pages) $paged = $total_pages;

    $start = ($paged - 1) * $per_page;
    $page_rows = array_slice($unique_rows, $start, $per_page);

    ob_start();
    ?>

    <style>
        /* ---------- FORM STYLE ---------- */
        .gp-filter-box { background: #f8f8f8; padding: 15px; border: 1px solid #ddd; margin-bottom: 20px; border-radius: 6px; }
        .gp-filter-input { width: 150px; padding: 6px; margin-right: 10px; font-size: 14px; }
        .gp-filter-btn { padding: 7px 18px; background: #0073aa; color: #fff; border: 0; cursor: pointer; border-radius: 4px; font-size: 14px; }

        /* ---------- TABLE BASE ---------- */
        .gp-table { width: 100%; border-collapse: collapse; background: #ffffff; table-layout: fixed; }

        .gp-table thead th {
            background: #0b4f7d;
            color: #fff;
            font-weight: 700;
            border: 1px solid #dbe2ef;
            padding: 10px 8px;
            text-align: center;
            font-size: 15px;
        }

        .gp-table tbody td {
            border: 1px solid #e1e6f0;
            padding: 10px 8px;
            font-size: 14px;
            vertical-align: top;
            white-space: normal;
            word-break: break-word;
        }

        .gp-table tbody tr:nth-child(even) { background: #f7f7f7; }

        /* ---------- COLUMN WIDTH CONTROL ---------- */

        /* 1: Serial */
        .gp-table th:nth-child(1),
        .gp-table td:nth-child(1) {
            width: 60px;
            min-width: 60px;
            text-align: center;
            white-space: nowrap;
        }

        /* 2: Type */
        .gp-table th:nth-child(2),
        .gp-table td:nth-child(2) {
            width: 180px;
            min-width: 180px;
            white-space: normal;
        }

        /* 3: Date */
        .gp-table th:nth-child(3),
        .gp-table td:nth-child(3) {
            width: 110px;
            min-width: 110px;
            text-align: center;
            white-space: nowrap;
        }

        /* 4: Title — SAME WIDTH AS COLUMN 2 */
        .gp-table th:nth-child(4),
        .gp-table td:nth-child(4) {
            width: 180px;
            min-width: 180px;
            white-space: normal;
        }

        /* 5: Subject */
        .gp-table th:nth-child(5),
        .gp-table td:nth-child(5) {
            min-width: 280px;
            max-width: 420px;
        }

        /* 6 & 7: Actions */
        .gp-table th:nth-child(6),
        .gp-table td:nth-child(6),
        .gp-table th:nth-child(7),
        .gp-table td:nth-child(7) {
            width: 110px;
            min-width: 110px;
            text-align: center;
            white-space: nowrap;
        }

        .gp-table td a {
            color: #ff4d2d;
            font-weight: 600;
            text-decoration: none;
        }
        .gp-table td a:hover { text-decoration: underline; }

        /* ---------- MOBILE (STILL TABLE, NO STACK) ---------- */
        @media (max-width: 768px) {

            .gp-table {
                display: block;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                font-size: 12px;
            }

            .gp-table th,
            .gp-table td {
                padding: 6px;
            }

            /* Fix first column number breaking */
            .gp-table th:nth-child(1),
            .gp-table td:nth-child(1) {
                width: 60px;
                min-width: 60px;
                white-space: nowrap;
                word-break: keep-all;
            }

            .gp-table th:nth-child(2),
            .gp-table td:nth-child(2),
            .gp-table th:nth-child(4),
            .gp-table td:nth-child(4) {
                width: 150px;
                min-width: 150px;
            }

            .gp-table th:nth-child(5),
            .gp-table td:nth-child(5) {
                min-width: 220px;
                max-width: 320px;
            }
        }

        /* ---------- PAGINATION ---------- */
        .gp-pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            margin-top: 15px;
            white-space: nowrap;
        }

        .gp-pagination a,
        .gp-pagination span {
            padding: 6px 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
            text-decoration: none;
        }

        .gp-pagination .active {
            background: #0d6efd;
            color: #fff;
            border-color: #0d6efd;
        }

        @media (max-width: 600px) {
            .gp-pagination { overflow-x: auto; }
        }
    </style>

    <div class="gp-filter-box">
        <form method="GET" style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
            <label style="font-weight:600;">તારીખ:</label>
            <input type="text" name="gp_date" class="gp-filter-input" placeholder="dd/mm/yyyy"
                   value="<?php echo esc_attr($_GET['gp_date'] ?? ''); ?>">

            <label style="font-weight:600;">શીર્ષક:</label>
            <input type="text" name="gp_title" class="gp-filter-input" value="<?php echo esc_attr($filter_title); ?>">

            <label style="font-weight:600;">વિષય:</label>
            <input type="text" name="gp_subject" class="gp-filter-input" value="<?php echo esc_attr($filter_subject); ?>">

            <label style="font-weight:600;">પરિપત્ર:</label>
            <select name="gp_type" class="gp-filter-input">
                <option value="">પસંદ કરો</option>
                <?php
                /* 🔥 FIX: only published posts in dropdown */
                $all = get_posts([
                    'post_type'   => 'paripatra',
                    'post_status' => 'publish',
                    'numberposts' => -1
                ]);
                $types = [];
                foreach ($all as $p) {
                    $t = gp_normalize_text(get_post_meta($p->ID, 'gp_type', true));
                    if ($t) $types[$t] = $t;
                }
                ksort($types, SORT_NATURAL);
                foreach ($types as $t) {
                    echo '<option value="' . esc_attr($t) . '" ' . selected($filter_type, $t, false) . '>' . esc_html($t) . '</option>';
                }
                ?>
            </select>

            <button type="submit" class="gp-filter-btn">અહીં શોધો</button>
        </form>
    </div>

    <table class="gp-table">
        <thead>
            <tr>
                <th>ક્રમ</th>
                <th>પરિપત્રનો પ્રકાર</th>
                <th>તારીખ</th>
                <th>શીર્ષક</th>
                <th>વિષય</th>
                <th>ડાઉનલોડ</th>
                <th>વાંચવા માટે</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $serial = $start + 1;

            if (!empty($page_rows)) {
                foreach ($page_rows as $row) {
                    $date = $row['dateRaw'] ? date("d-m-Y", strtotime($row['dateRaw'])) : '';
                    ?>
                    <tr>
                        <td><?php echo intval($serial++); ?></td>
                        <td><?php echo esc_html($row['type']); ?></td>
                        <td><?php echo esc_html($date); ?></td>
                        <td><?php echo esc_html($row['title']); ?></td>
                        <td><?php echo esc_html($row['subject']); ?></td>
                        <td><?php if ($row['pdf']): ?><a href="<?php echo esc_url($row['pdf']); ?>" download>ડાઉનલોડ</a><?php endif; ?></td>
                        <td><?php if ($row['pdf']): ?><a href="<?php echo esc_url($row['pdf']); ?>" target="_blank">વાંચવા માટે</a><?php endif; ?></td>
                    </tr>
                    <?php
                }
            } else {
                echo '<tr><td colspan="7" style="padding:12px;">No records found.</td></tr>';
            }
            ?>
        </tbody>
    </table>

    <div class="gp-pagination">
        <?php
        $base_url = remove_query_arg('pg');
        $base_url .= (strpos($base_url, '?') === false ? '?' : '&');

        if ($paged > 1) {
            echo '<a href="' . esc_url($base_url . 'pg=' . ($paged - 1)) . '">« પૃષ્ઠ</a>';
        }

        if ($paged > 2) {
            echo '<a href="' . esc_url($base_url . 'pg=1') . '">1</a>';
        }

        if ($paged > 3) {
            echo '<span>…</span>';
        }

        if ($paged - 1 >= 1) {
            echo '<a href="' . esc_url($base_url . 'pg=' . ($paged - 1)) . '">' . ($paged - 1) . '</a>';
        }

        echo '<span class="active">' . intval($paged) . '</span>';

        if ($paged + 1 <= $total_pages) {
            echo '<a href="' . esc_url($base_url . 'pg=' . ($paged + 1)) . '">' . ($paged + 1) . '</a>';
        }

        if ($paged < $total_pages - 2) {
            echo '<span>…</span>';
        }

        if ($paged < $total_pages - 1) {
            echo '<a href="' . esc_url($base_url . 'pg=' . $total_pages) . '">' . $total_pages . '</a>';
        }

        if ($paged < $total_pages) {
            echo '<a href="' . esc_url($base_url . 'pg=' . ($paged + 1)) . '">આગળ »</a>';
        }
        ?>
    </div>

    <script>
        jQuery(document).ready(function ($) {
            var $title = $('#title');
            var $gpType = $('#gp_type');
            if (!$gpType.length) $gpType = $('input[name="gp_type"]');

            if ($gpType.length && $title.length && !$gpType.val().trim()) $gpType.val($title.val());

            $gpType.on('input', function () { $(this).data('manualEdit', true); });

            $title.on('input change', function () {
                if (!$gpType.data('manualEdit')) $gpType.val($(this).val());
            });

            $gpType.on('input', function () {
                if (!$(this).val().trim()) $(this).data('manualEdit', false);
            });
        });
    </script>

    <?php
    return ob_get_clean();
}
add_shortcode('paripatra_table', 'gp_table_shortcode');

/* ----------------------------------------------------------
   ADMIN FOOTER SYNC (SAFE)
---------------------------------------------------------- */
add_action('admin_footer', function () {
    ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            function syncParipatraType() {
                const titleInput = document.querySelector('#title');
                const paripatraInput = document.querySelector('#gp_type') || document.querySelector('input[name="gp_type"]');
                if (!titleInput || !paripatraInput) return;

                if (!paripatraInput.value || !paripatraInput.value.trim()) paripatraInput.value = titleInput.value;

                titleInput.addEventListener('input', function () {
                    const manualEdit = paripatraInput.dataset.manualEdit === '1';
                    const isEmptyNow = !paripatraInput.value || !paripatraInput.value.trim();
                    if (!manualEdit || isEmptyNow) paripatraInput.value = this.value;
                });

                paripatraInput.addEventListener('input', function () {
                    if (this.value && this.value.trim() && this.value !== titleInput.value) this.dataset.manualEdit = '1';
                    else if (!this.value || !this.value.trim()) this.dataset.manualEdit = '0';
                });
            }
            syncParipatraType();
        });
    </script>
    <?php
});
